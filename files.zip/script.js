/* Yum Yum Kitchen - shared shopping logic. Runs on every page. */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const money = n => CONFIG.currency + n.toFixed(2);
const unit = p => p.sale ?? p.price;
const byId = id => PRODUCTS.find(p => p.id == id);
let cart = {};
try { cart = JSON.parse(localStorage.getItem("yyk_cart")) || {}; } catch (e) {} // cart holds ids + quantities only, never payment data
const save = () => { try { localStorage.setItem("yyk_cart", JSON.stringify(cart)); } catch (e) {} $$(".cart-count").forEach(c => c.textContent = count()); };
const count = () => Object.values(cart).reduce((a, b) => a + b, 0);
const setQty = (id, q) => { q > 0 ? cart[id] = Math.min(q, 99) : delete cart[id]; save(); };
const subtotal = () => Object.entries(cart).reduce((s, [id, q]) => s + unit(byId(id)) * q, 0);
const delivery = s => (s === 0 || (CONFIG.freeDeliveryOver && s >= CONFIG.freeDeliveryOver)) ? 0 : CONFIG.deliveryFee;
const toast = msg => { let t = $("#toast"); if (!t) { t = document.createElement("div"); t.id = "toast"; t.setAttribute("role", "status"); document.body.append(t); } t.textContent = msg; t.className = "show"; setTimeout(() => t.className = "", 2000); };

/* ---------- Header and footer ---------- */
function chrome() {
  const nav = [["index.html", "Home"], ["shop.html", "Shop All"], ["shop.html?cat=fruits", "Fresh Fruits"], ["shop.html?cat=vegetables", "Vegetables"], ["shop.html?cat=raw", "Raw Foods"], ["shop.html?cat=bottled", "Bottled Juices"], ["shop.html?cat=canned", "Canned Juices"], ["about.html", "About Us"], ["contact.html", "Contact"]];
  $("#hdr").innerHTML = `<a class="skip" href="#main">Skip to content</a><header class="site"><div class="bar">
  <a class="logo" href="index.html"><span class="mark">🥝</span>Yum Yum Kitchen</a>
  <form class="search" action="shop.html" role="search"><input name="q" type="search" placeholder="Search products" aria-label="Search products"><button aria-label="Search">🔍</button></form>
  <a class="cartlink" href="cart.html" aria-label="Shopping cart">🛒<b class="cart-count">0</b></a>
  <button class="burger" aria-label="Menu" aria-expanded="false">☰</button></div>
  <nav id="nav" aria-label="Main">${nav.map(n => `<a href="${n[0]}">${n[1]}</a>`).join("")}</nav></header>`;
  $(".burger").onclick = e => { const o = $("#nav").classList.toggle("open"); e.target.setAttribute("aria-expanded", o); };
  $("#ftr").innerHTML = `<footer class="site"><div class="fgrid"><div><div class="logo"><span class="mark">🥝</span>Yum Yum Kitchen</div><p>Fresh produce, raw foods and juices, ordered online.</p></div>
  <div><h3>Shop</h3>${Object.entries(CATEGORIES).map(([k, v]) => `<a href="shop.html?cat=${k}">${v[1]}</a>`).join("")}</div>
  <div><h3>Help</h3><a href="about.html">About Us</a><a href="contact.html">Contact</a><a href="about.html#faq">FAQ</a><a href="about.html#delivery">Delivery &amp; Returns</a><a href="about.html#privacy">Privacy Policy</a><a href="about.html#terms">Terms &amp; Conditions</a></div>
  <div><h3>Contact</h3><p>${CONFIG.phone}<br>${CONFIG.email}<br>${CONFIG.address}</p><p>Social: [Facebook] [Instagram] [TikTok] (add your links)</p></div></div>
  <p class="copy">© ${new Date().getFullYear()} Yum Yum Kitchen. All rights reserved.</p></footer>`;
  $$("#nav a").forEach(a => { if (a.getAttribute("href") === location.pathname.split("/").pop() + location.search || (!location.search && a.getAttribute("href") === (location.pathname.split("/").pop() || "index.html"))) a.setAttribute("aria-current", "page"); });
  save();
}

/* ---------- Product cards ---------- */
function card(p) {
  const off = p.sale ? Math.round((1 - p.sale / p.price) * 100) : 0;
  const img = p.image ? `<img src="${p.image}" alt="${p.name}">` : `<span role="img" aria-label="${p.name}">${p.icon}</span>`;
  return `<article class="card"><div class="pic">${img}${off ? `<em class="off">${off}% off</em>` : ""}</div><h3>${p.name}</h3><p class="size">${p.size}</p>
  <p class="price">${p.sale ? `<s>${money(p.price)}</s> ` : ""}${money(unit(p))}</p>
  <p class="${p.stock ? "in" : "out"}">${p.stock ? "In stock" : "Out of stock"}</p>
  <div class="buy"><input type="number" min="1" max="99" value="1" aria-label="Quantity of ${p.name}" ${p.stock ? "" : "disabled"}><button class="btn" data-add="${p.id}" ${p.stock ? "" : "disabled"}>Add to Cart</button></div></article>`;
}
document.addEventListener("click", e => {
  const b = e.target.closest("[data-add]"); if (!b) return;
  const q = parseInt($("input", b.parentElement).value) || 1;
  setQty(b.dataset.add, (cart[b.dataset.add] || 0) + q); toast("Added to cart");
});

/* ---------- Pages ---------- */
const pages = {
  home() {
    $("#cats").innerHTML = Object.entries(CATEGORIES).map(([k, v]) => `<a class="cat" href="shop.html?cat=${k}"><span role="img" aria-label="${v[1]}">${v[0]}</span><h3>${v[1]}</h3><b>Shop Now</b></a>`).join("");
    $("#featured").innerHTML = PRODUCTS.slice(0, 12).map(card).join("");
    $("#offers").innerHTML = PRODUCTS.filter(p => p.sale).map(card).join("");
    const f = $("#news"); f.onsubmit = e => { e.preventDefault(); const m = $("#newsmsg"), v = f.email.value.trim();
      const ok = /^\S+@\S+\.\S+$/.test(v); m.className = ok ? "ok" : "err";
      m.textContent = ok ? "Thanks! (Demo only: connect a real email service before launch.)" : "Please enter a valid email address."; };
  },
  shop() {
    const p = new URLSearchParams(location.search), f = $("#filters");
    $("#fcat").innerHTML = `<option value="">All categories</option>` + Object.entries(CATEGORIES).map(([k, v]) => `<option value="${k}">${v[1]}</option>`).join("");
    f.q.value = p.get("q") || ""; f.cat.value = p.get("cat") || "";
    const draw = () => {
      const q = f.q.value.toLowerCase(), lo = parseFloat(f.min.value) || 0, hi = parseFloat(f.max.value) || Infinity;
      let list = PRODUCTS.filter(x => x.name.toLowerCase().includes(q) && (!f.cat.value || x.cat === f.cat.value) && unit(x) >= lo && unit(x) <= hi && (!f.stock.checked || x.stock));
      if (f.sort.value) list.sort((a, b) => (unit(a) - unit(b)) * f.sort.value);
      $("#results").innerHTML = list.length ? list.map(card).join("") : `<p class="empty">No products match. Try clearing the filters.</p>`;
      $("#found").textContent = list.length + " products";
    };
    f.oninput = draw; f.onsubmit = e => e.preventDefault();
    f.onreset = () => setTimeout(draw); draw();
  },
  cart() {
    const draw = () => {
      const ids = Object.keys(cart), s = subtotal();
      $("#cartbody").innerHTML = ids.length ? ids.map(id => { const p = byId(id); return `<div class="line"><span class="ic" aria-hidden="true">${p.icon}</span><div><b>${p.name}</b><br><small>${p.size} · ${money(unit(p))}</small></div>
        <div class="qty"><button data-d="${id}" aria-label="Decrease ${p.name}">−</button><span>${cart[id]}</span><button data-i="${id}" aria-label="Increase ${p.name}">+</button></div>
        <b>${money(unit(p) * cart[id])}</b><button class="rm" data-r="${id}" aria-label="Remove ${p.name}">✕</button></div>`; }).join("")
        : `<p class="empty">Your cart is empty. <a href="shop.html">Start shopping</a></p>`;
      summary("#sum"); $("#tocheckout").hidden = !ids.length;
    };
    $("#cartbody").onclick = e => { const t = e.target; if (t.dataset.i) setQty(t.dataset.i, cart[t.dataset.i] + 1); if (t.dataset.d) setQty(t.dataset.d, cart[t.dataset.d] - 1); if (t.dataset.r) setQty(t.dataset.r, 0); draw(); };
    draw();
  },
  checkout() {
    if (!count()) { $("#co").innerHTML = `<p class="empty">Your cart is empty. <a href="shop.html">Start shopping</a></p>`; return; }
    summary("#sum");
    const f = $("#form"), msg = $("#cmsg");
    f.onsubmit = e => {
      e.preventDefault(); const s = subtotal();
      if (!f.checkValidity()) { msg.className = "err"; msg.textContent = "Please complete all required fields correctly."; f.reportValidity(); return; }
      if (s < CONFIG.minOrder) { msg.className = "err"; msg.textContent = `Minimum order is ${money(CONFIG.minOrder)}.`; return; }
      const lines = Object.entries(cart).map(([id, q]) => `- ${byId(id).name} x${q} = ${money(unit(byId(id)) * q)}`).join("\n");
      const text = `New order - Yum Yum Kitchen\n${lines}\nSubtotal: ${money(s)}\nDelivery: ${money(delivery(s))}\nTotal: ${money(s + delivery(s))}\n\nName: ${f.name.value}\nPhone: ${f.phone.value}\nEmail: ${f.email.value}\nAddress: ${f.address.value}\nNotes: ${f.notes.value || "-"}`;
      if (!CONFIG.whatsappNumber) { msg.className = "err"; msg.textContent = "Store owner: set whatsappNumber in products.js to enable WhatsApp orders."; return; }
      window.open(`https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(text)}`, "_blank");
      msg.className = "ok"; msg.textContent = "WhatsApp opened with your order. It is not confirmed or paid until the shop replies.";
    };
  },
  contact() { $("#cinfo").innerHTML = `<li>Phone: ${CONFIG.phone}</li><li>WhatsApp: ${CONFIG.whatsappNumber || "[WhatsApp number]"}</li><li>Email: ${CONFIG.email}</li><li>Address: ${CONFIG.address}</li><li>Opening hours: ${CONFIG.hours}</li><li>Delivery areas: ${CONFIG.deliveryAreas}</li><li>Delivery fee: ${money(CONFIG.deliveryFee)} (free over ${money(CONFIG.freeDeliveryOver)}). Minimum order: ${money(CONFIG.minOrder)}</li>`; }
};
function summary(sel) {
  const s = subtotal(), d = delivery(s);
  $(sel).innerHTML = `<h2>Order summary</h2>` + Object.entries(cart).map(([id, q]) => `<p>${byId(id).name} × ${q}<span>${money(unit(byId(id)) * q)}</span></p>`).join("") +
    `<p>Subtotal<span>${money(s)}</span></p><p>Delivery<span>${money(d)}</span></p><p class="tot">Total<span>${money(s + d)}</span></p>` +
    (s && s < CONFIG.minOrder ? `<p class="err">Minimum order is ${money(CONFIG.minOrder)}.</p>` : "");
}
chrome(); const run = pages[document.body.dataset.page]; if (run) run();
