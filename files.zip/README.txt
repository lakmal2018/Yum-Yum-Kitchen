RUN LOCALLY: keep all files in one folder and double-click index.html (no install needed).
EDIT: prices, products, phone/WhatsApp, delivery fees and minimum order are all in products.js.
PUBLISH: upload the folder to Netlify Drop, GitHub Pages or Cloudflare Pages (all free, HTTPS included).
BEFORE REAL SALES: replace sample prices, placeholder reviews, policies and contact details.
TO GO PRODUCTION: add a backend + database (products/orders), inventory, a payment gateway for your country (Stripe, PayHere, etc.),
email/WhatsApp notifications, login if needed, HTTPS and server-side validation. Never store card details in the browser.
