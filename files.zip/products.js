/* ===== EDIT ME: store settings and product catalogue ===== */
const CONFIG = {
  currency: "$",
  whatsappNumber: "",            // e.g. "94771234567" (country code, no + or spaces)
  phone: "[Your phone number]", email: "[your@email.com]",
  address: "[Your business address]", hours: "[Opening hours]",
  deliveryAreas: "[List your delivery areas]",
  deliveryFee: 3.50,             // charged below the free-delivery value
  freeDeliveryOver: 40,          // set to 0 to always charge the fee
  minOrder: 10                   // minimum order value
};
const CATEGORIES = {
  fruits: ["🍎", "Fresh Fruits"], vegetables: ["🥕", "Fresh Vegetables"],
  raw: ["🥗", "Raw Foods & Salad Ingredients"], bottled: ["🍹", "Bottled Fruit Juices"],
  canned: ["🥫", "Canned Juices"], drinks: ["🥤", "Healthy Drinks"]
};
// SAMPLE PRICES - replace with real prices before launch.
// "sale" is optional: set it to show a discount. "image" is optional: add a photo path (e.g. "img/apples.jpg").
const PRODUCTS = [
  { id: 1, name: "Fresh Red Apples", cat: "fruits", price: 4.5, size: "1 kg", stock: true, icon: "🍎" },
  { id: 2, name: "Ripe Bananas", cat: "fruits", price: 2.2, sale: 1.8, size: "1 kg", stock: true, icon: "🍌" },
  { id: 3, name: "Fresh Oranges", cat: "fruits", price: 3.9, size: "1 kg", stock: true, icon: "🍊" },
  { id: 4, name: "Green Grapes", cat: "fruits", price: 5.5, size: "500 g", stock: false, icon: "🍇" },
  { id: 5, name: "Fresh Carrots", cat: "vegetables", price: 1.9, size: "500 g", stock: true, icon: "🥕" },
  { id: 6, name: "Organic Spinach", cat: "vegetables", price: 2.5, size: "250 g bunch", stock: true, icon: "🥬" },
  { id: 7, name: "Fresh Tomatoes", cat: "vegetables", price: 2.8, sale: 2.2, size: "500 g", stock: true, icon: "🍅" },
  { id: 8, name: "Mixed Salad Pack", cat: "raw", price: 4.2, size: "300 g pack", stock: true, icon: "🥗" },
  { id: 9, name: "Orange Juice Bottle", cat: "bottled", price: 3.6, size: "1 L bottle", stock: true, icon: "🍊" },
  { id: 10, name: "Mango Juice Bottle", cat: "bottled", price: 3.9, sale: 3.1, size: "1 L bottle", stock: true, icon: "🥭" },
  { id: 11, name: "Apple Juice Can", cat: "canned", price: 1.5, size: "330 ml can", stock: true, icon: "🥫" },
  { id: 12, name: "Tropical Fruit Juice Can", cat: "canned", price: 1.7, sale: 1.4, size: "330 ml can", stock: true, icon: "🍍" },
  { id: 13, name: "Coconut Water", cat: "drinks", price: 2.4, size: "500 ml", stock: true, icon: "🥥" },
  { id: 14, name: "Fresh Herbs Bundle", cat: "raw", price: 2.1, size: "100 g", stock: true, icon: "🌿" }
];
